plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.nova.fx"; compileSdk = 34
    defaultConfig {
        applicationId = "com.nova.fx"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "0.1"
        ndk { abiFilters += "arm64-v8a" }   // G88 is arm64: halves APK size
    }
    buildTypes { release { isMinifyEnabled = true; isShrinkResources = true
        proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt")) } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { testImplementation("junit:junit:4.13.2") }   // no UI/lib bloat
