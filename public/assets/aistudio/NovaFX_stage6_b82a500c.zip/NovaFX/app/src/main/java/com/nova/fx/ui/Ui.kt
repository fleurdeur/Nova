package com.nova.fx.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.widget.LinearLayout
import android.widget.TextView
import com.nova.fx.Prefs

/** Tiny dark-theme toolkit shared by every screen (no XML, no image assets). */
object Ui {
    val BG = 0xFF0E0E11.toInt(); val PANEL = 0xFF17171B.toInt(); val CARD = 0xFF1F1F25.toInt(); val CHIP = 0xFF26262D.toInt(); val MUTED = 0xFF9A9AA5.toInt()
    private val palette = intArrayOf(0xFF7C4DFF.toInt(), 0xFF00BCD4.toInt(), 0xFFFF5252.toInt(), 0xFFFFB300.toInt(), 0xFF4CAF50.toInt())
    val paletteNames = listOf("Violet", "Cyan", "Red", "Amber", "Green")
    fun accent() = palette[Prefs.accent.coerceIn(0, palette.size - 1)]
    fun dp(c: Context, v: Float) = (v * c.resources.displayMetrics.density).toInt()
    fun round(c: Context, color: Int, r: Float = 12f) = GradientDrawable().apply { setColor(color); cornerRadius = r * c.resources.displayMetrics.density }

    fun text(c: Context, s: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false) = TextView(c).apply {
        text = s; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD) }

    fun chip(c: Context, s: String, selected: Boolean = false, onClick: (TextView) -> Unit) = TextView(c).apply {
        text = s; textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        background = round(c, if (selected) accent() else CHIP, 10f); setPadding(dp(c, 12f), dp(c, 9f), dp(c, 12f), dp(c, 9f))
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(c, 4f), dp(c, 6f), dp(c, 4f), dp(c, 6f)) }
        setOnClickListener { if (Prefs.haptics) it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); onClick(this) }
    }

    fun card(c: Context) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL; background = round(c, CARD); setPadding(dp(c, 14f), dp(c, 12f), dp(c, 14f), dp(c, 12f))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(c, 6f), 0, dp(c, 6f)) }
    }
}
