package com.nova.fx.model

import android.net.Uri
import java.util.concurrent.CopyOnWriteArrayList

enum class BlendMode { NORMAL, ADD, MULTIPLY, SCREEN }   // fixed-function = no framebuffer read (cheap on Mali tilers)

class Transform {
    val x = AnimatedFloat(); val y = AnimatedFloat()
    val scaleX = AnimatedFloat(1f); val scaleY = AnimatedFloat(1f)
    val rotation = AnimatedFloat()               // degrees
    val rotX = AnimatedFloat(); val rotY = AnimatedFloat()          // only used when Layer.threeD
    val anchorX = AnimatedFloat(); val anchorY = AnimatedFloat()
}

sealed interface Source {
    data class Solid(val r: Float, val g: Float, val b: Float) : Source
    class Video(val uri: Uri) : Source
    class Raster(val bitmap: android.graphics.Bitmap, val photo: Boolean = false) : Source { var glId = 0; var gen = -1 }   // text & shapes
    class Texture(var glId: Int = 0, val width: Int, val height: Int) : Source   // image/video frame
}

class Layer(
    val id: Int, var source: Source, val width: Float, val height: Float,
    var inMs: Long = 0, var outMs: Long = Long.MAX_VALUE, var blend: BlendMode = BlendMode.NORMAL, var trimMs: Long = 0
) {
    // Single-pass colour adjust: runs inside the main fragment shader, so it costs no extra render pass.
    var name = ""
    var threeD = false
    var maskType = 0; var maskInvert = false                         // 0 none, 1 rectangle, 2 ellipse; coordinates in layer space 0..1
    val maskX = AnimatedFloat(0.5f); val maskY = AnimatedFloat(0.5f); val maskW = AnimatedFloat(0.5f); val maskH = AnimatedFloat(0.5f)
    val maskFeather = AnimatedFloat(0.02f)
    var audioUri: Uri? = null                                         // original file whose audio is copied on export
    var timeMode = 0                                                  // slow-motion/remap frame synthesis: 0 nearest, 1 frame blend, 2 optical flow
    var volume = 1f; var fadeInMs = 0L; var fadeOutMs = 0L
    fun props(): Map<String, AnimatedFloat> {                         // stable names, used by project save/load
        val m = LinkedHashMap<String, AnimatedFloat>(); val t = transform
        m["x"] = t.x; m["y"] = t.y; m["sx"] = t.scaleX; m["sy"] = t.scaleY; m["rot"] = t.rotation; m["rx"] = t.rotX; m["ry"] = t.rotY; m["ax"] = t.anchorX; m["ay"] = t.anchorY
        m["op"] = opacity; m["br"] = brightness; m["ct"] = contrast; m["sa"] = saturation; m["rs"] = rgbSplit; m["vg"] = vignette; m["pz"] = posterize; m["gr"] = grain
        m["remap"] = remap; m["mx"] = maskX; m["my"] = maskY; m["mw"] = maskW; m["mh"] = maskH; m["mf"] = maskFeather
        for (i in e.indices) m["e$i"] = e[i]
        return m
    }
    fun animatedProps() = listOf(transform.x, transform.y, transform.scaleX, transform.scaleY, transform.rotation, transform.rotX, transform.rotY,
        opacity, maskX, maskY, maskW, maskH, maskFeather)
    // --- time: speed, reverse, AE-style time remap (remap = source seconds as a keyframed function of timeline time) ---
    var speed = 1f; var reversed = false; var srcDurMs = 0L
    val remap = AnimatedFloat(0f)
    val e = Array(FX.size) { AnimatedFloat(0f) }                   // effect amounts, see Effects.kt
    fun srcMs(t: Long): Long {
        if (remap.isAnimated) return maxOf(0L, (remap.valueAt(t) * 1000).toLong())
        val local = ((t - inMs) * speed).toLong()
        return maxOf(0L, if (!reversed) trimMs + local else trimMs + ((outMs - inMs) * speed).toLong() - local)
    }
    /** Turn on time remap with two linear keys that reproduce the current speed/reverse; then edit them. */
    fun seedRemap() { if (remap.isAnimated) return
        val a = srcMs(inMs) / 1000f; val b = srcMs(outMs) / 1000f
        remap.set(Keyframe(inMs, a, Interp.LINEAR)); remap.set(Keyframe(outMs, b, Interp.LINEAR)) }
    val rgbSplit = AnimatedFloat(0f); val vignette = AnimatedFloat(0f); val posterize = AnimatedFloat(0f); val grain = AnimatedFloat(0f)
    val brightness = AnimatedFloat(0f); val contrast = AnimatedFloat(1f); val saturation = AnimatedFloat(1f)
    val transform = Transform()
    val opacity = AnimatedFloat(1f)
    var parent: Layer? = null
}

class Project(var width: Int = 1280, var height: Int = 720, var fps: Int = 30, var durationMs: Long = 5000) {
    val layers = CopyOnWriteArrayList<Layer>()    // index 0 = bottom
}
