package com.nova.fx.ui

import android.content.Context
import android.graphics.*
import android.view.*
import com.nova.fx.EditorState
import com.nova.fx.model.Source
import kotlin.math.max

/** Ruler: drag = scrub. Clip body: select + move. Clip edges: trim. Empty area: pan. Pinch: zoom. */
class TimelineView(c: Context, private val st: EditorState, private val onChange: () -> Unit) : View(c) {
    private enum class Mode { NONE, SCRUB, PAN, MOVE, TRIML, TRIMR }
    private val dp = resources.displayMetrics.density
    private var pps = 80f; private var off = 0f
    private val rulerH = 26 * dp; private val rowH = 34 * dp; private val edge = 18 * dp
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG); private val grid = Paint().apply { color = 0xFF2E2E36.toInt() }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 11 * dp }
    private val head = Paint().apply { color = 0xFFFF5252.toInt(); strokeWidth = 2 * dp }
    private val sel = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.WHITE; strokeWidth = 2 * dp }
    private val colors = intArrayOf(0xFF5C6BC0.toInt(), 0xFF26A69A.toInt(), 0xFFEF6C00.toInt(), 0xFF8E24AA.toInt())
    private var mode = Mode.NONE; private var target: com.nova.fx.model.Layer? = null; private var lastX = 0f
    private val scale = ScaleGestureDetector(c, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(g: ScaleGestureDetector): Boolean { pps = (pps * g.scaleFactor).coerceIn(10f, 600f); invalidate(); return true } })

    override fun onDraw(cv: Canvas) {
        cv.drawColor(0xFF121216.toInt())
        val dur = st.project.durationMs
        for (s in (off / pps).toInt()..minOf(((off + width) / pps).toInt() + 1, (dur / 1000).toInt())) {
            val x = s * pps - off; cv.drawLine(x, rulerH - 8 * dp, x, height.toFloat(), grid); cv.drawText("${s}s", x + 3 * dp, rulerH - 10 * dp, txt)
        }
        for ((i, l) in st.project.layers.withIndex()) {
            val x0 = l.inMs / 1000f * pps - off; val x1 = minOf(l.outMs, dur) / 1000f * pps - off
            if (x1 < 0 || x0 > width) continue
            val y = rulerH + 4 * dp + i * rowH; val r = RectF(x0, y, x1, y + rowH - 4 * dp)
            bar.color = colors[i % colors.size]; cv.drawRoundRect(r, 6 * dp, 6 * dp, bar)
            cv.drawText(l.name.ifEmpty { if (l.source is Source.Video) "Video ${l.id}" else "Layer ${l.id}" }, x0 + 10 * dp, y + rowH / 2 + 2 * dp, txt)
            if (l === st.selected) { cv.drawRoundRect(r, 6 * dp, 6 * dp, sel); cv.drawRect(x0, y + 6 * dp, x0 + 4 * dp, r.bottom - 6 * dp, bar.apply { color = Color.WHITE }); cv.drawRect(x1 - 4 * dp, y + 6 * dp, x1, r.bottom - 6 * dp, bar) }
        }
        val px = (st.posMs / 1000.0 * pps - off).toFloat(); cv.drawLine(px, 0f, px, height.toFloat(), head)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        scale.onTouchEvent(e); if (scale.isInProgress) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x
                if (e.y < rulerH) { mode = Mode.SCRUB; seek(e.x) } else {
                    val l = st.project.layers.getOrNull(((e.y - rulerH - 4 * dp) / rowH).toInt())
                    if (l != null && e.x >= l.inMs / 1000f * pps - off && e.x <= minOf(l.outMs, st.project.durationMs) / 1000f * pps - off) {
                        st.selected = l; target = l; val x0 = l.inMs / 1000f * pps - off; val x1 = minOf(l.outMs, st.project.durationMs) / 1000f * pps - off
                        mode = when { e.x < x0 + edge -> Mode.TRIML; e.x > x1 - edge -> Mode.TRIMR; else -> Mode.MOVE }
                    } else { st.selected = null; mode = Mode.PAN }
                    invalidate()
                }
            }
            MotionEvent.ACTION_MOVE -> {
                val dMs = ((e.x - lastX) / pps * 1000).toLong(); val l = target
                when (mode) {
                    Mode.SCRUB -> seek(e.x)
                    Mode.PAN -> { off = (off - (e.x - lastX)).coerceAtLeast(0f); lastX = e.x; invalidate() }
                    Mode.MOVE -> if (l != null) { val d = max(dMs, -l.inMs); l.inMs += d; l.outMs += d; lastX = e.x; onChange(); invalidate() }
                    Mode.TRIML -> if (l != null) { val lo = if (l.source is Source.Video) -minOf(l.inMs, l.trimMs) else -l.inMs
                        val d = dMs.coerceIn(lo, l.outMs - l.inMs - 100); l.inMs += d; l.trimMs += d; lastX = e.x; onChange(); invalidate() }
                    Mode.TRIMR -> if (l != null) { l.outMs = max(l.inMs + 100, l.outMs + dMs); lastX = e.x; onChange(); invalidate() }
                    Mode.NONE -> {}
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (mode == Mode.MOVE || mode == Mode.TRIMR || mode == Mode.TRIML)
                    st.project.durationMs = max(1000L, st.project.layers.maxOfOrNull { minOf(it.outMs, 600_000L) } ?: 1000L)
                mode = Mode.NONE; onChange(); invalidate()
            }
        }
        return true
    }
    private fun seek(x: Float) { st.posMs = ((x + off) / pps * 1000.0).coerceIn(0.0, st.project.durationMs.toDouble()); onChange(); invalidate() }
}
