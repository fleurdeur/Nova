package com.nova.fx.model

/** One entry per shader slot (uE[i]). 0 = off. Order is part of the shader contract: do not reorder. */
class Fx(val name: String, val min: Float, val max: Float)

val FX = listOf(
    Fx("Invert", 0f, 1f), Fx("Sepia", 0f, 1f), Fx("Hue shift", -0.5f, 0.5f), Fx("Temperature", -1f, 1f),
    Fx("Threshold (B/W)", 0f, 1f), Fx("Duotone", 0f, 1f), Fx("Sharpen", 0f, 2f), Fx("Blur", 0f, 8f),
    Fx("Glow", 0f, 2f), Fx("Pixelate", 0f, 1f), Fx("Wave", 0f, 1f), Fx("Swirl", -1f, 1f),
    Fx("Bulge / fisheye", -1f, 1f), Fx("Mirror", 0f, 1f), Fx("Scanlines", 0f, 1f), Fx("Glitch", 0f, 1f),
    Fx("Edge detect", 0f, 1f), Fx("Halftone", 0f, 1f), Fx("Chromatic aberration", 0f, 0.03f), Fx("Flicker", 0f, 1f),
    Fx("Zoom blur", 0f, 0.4f), Fx("Exposure", -2f, 2f), Fx("Green screen key", 0f, 1f)
)
