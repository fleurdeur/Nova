package com.nova.fx.model

import kotlin.math.abs

enum class Interp { LINEAR, HOLD, BEZIER }

/** Bezier handles follow CSS cubic-bezier: out-handle of this key, in-handle of the NEXT key. */
data class Keyframe(
    val timeMs: Long, val value: Float, val interp: Interp = Interp.BEZIER,
    val outX: Float = 0.42f, val outY: Float = 0f, val inX: Float = 0.58f, val inY: Float = 1f
)

/** Allocation-free animated property. Keys must be sorted by time (use [set]). */
class AnimatedFloat(var base: Float = 0f) {
    private val keys = java.util.concurrent.CopyOnWriteArrayList<Keyframe>()   // UI thread may save while GL thread plays
    private var hint = 0   // playback is mostly sequential: start search from the last segment

    fun set(k: Keyframe) {
        val i = keys.indexOfFirst { it.timeMs >= k.timeMs }
        when { i < 0 -> keys.add(k); keys[i].timeMs == k.timeMs -> keys[i] = k; else -> keys.add(i, k) }
    }
    val isAnimated get() = keys.isNotEmpty()
    fun keyList(): List<Keyframe> = keys.toList()
    /** Set the Bezier easing (CSS cubic-bezier handles) on every keyframe of this property. */
    fun applyEase(ox: Float, oy: Float, ix: Float, iy: Float) { keys.replaceAll { it.copy(interp = Interp.BEZIER, outX = ox, outY = oy, inX = ix, inY = iy) } }
    /** Auto-key edit: writes a keyframe at [t] if the property is animated (or auto-key is on), else changes the base value. */
    fun put(t: Long, v: Float, autoKey: Boolean) { if (isAnimated || autoKey) set(Keyframe(t, v)) else base = v }

    fun valueAt(t: Long): Float {
        val n = keys.size
        if (n == 0) return base
        if (t <= keys[0].timeMs) return keys[0].value
        if (t >= keys[n - 1].timeMs) return keys[n - 1].value
        var i = if (hint in 0 until n - 1 && keys[hint].timeMs <= t) hint else 0
        while (keys[i + 1].timeMs <= t) i++
        hint = i
        val a = keys[i]; val b = keys[i + 1]
        val u = (t - a.timeMs).toFloat() / (b.timeMs - a.timeMs)
        val e = when (a.interp) {
            Interp.HOLD -> return a.value
            Interp.LINEAR -> u
            Interp.BEZIER -> bezier(u, a.outX, a.outY, a.inX, a.inY)
        }
        return a.value + (b.value - a.value) * e
    }

    companion object {
        /** Solve x(s)=u on a cubic Bezier from (0,0) to (1,1); return y(s). Newton, bisection fallback. */
        fun bezier(u: Float, x1: Float, y1: Float, x2: Float, y2: Float): Float {
            fun c(a: Float, b: Float, s: Float) = ((1 - 3 * b + 3 * a) * s + (3 * b - 6 * a)) * s * s + 3 * a * s  // ((..)s+..)s^2+3as
            fun cx(s: Float) = c(x1, x2, s)
            fun cy(s: Float) = c(y1, y2, s)
            fun dx(s: Float) = 3 * (1 - 3 * x2 + 3 * x1) * s * s + 2 * (3 * x2 - 6 * x1) * s + 3 * x1
            var s = u
            repeat(5) {
                val err = cx(s) - u
                if (abs(err) < 1e-4f) return cy(s)
                val d = dx(s); if (abs(d) < 1e-6f) return@repeat
                s -= err / d
            }
            var lo = 0f; var hi = 1f; s = u
            repeat(16) { if (cx(s) < u) lo = s else hi = s; s = (lo + hi) / 2 }
            return cy(s)
        }
    }
}
