package com.nova.fx.export

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.opengl.*
import com.nova.fx.gl.Compositor
import com.nova.fx.model.Project
import java.io.File

/** Offline (faster/slower than real-time, frame-exact) render -> hardware H.264 encoder input surface -> MP4. Call off the UI thread. */
class Exporter(private val ctx: Context, private val project: Project) {
    private val info = MediaCodec.BufferInfo()
    private lateinit var enc: MediaCodec; private lateinit var mux: MediaMuxer
    private var track = -1; private var muxStarted = false
    private var audioTrack = -1; private var audio: AudioSource? = null

    fun run(out: File, bitrate: Int = 8_000_000, allIntra: Boolean = false, mime: String = MediaFormat.MIMETYPE_VIDEO_AVC, scale: Float = 1f, onProgress: (Float) -> Unit) {
        val w = (project.width * scale).toInt() / 2 * 2; val h = (project.height * scale).toInt() / 2 * 2; val fps = project.fps
        val useMime = if (mime == MediaFormat.MIMETYPE_VIDEO_HEVC && hasEncoder(mime)) mime else MediaFormat.MIMETYPE_VIDEO_AVC
        audio = (AudioMix.create(ctx, project) ?: AudioCopy(ctx, project)).takeIf { it.format != null }
        val fmt = MediaFormat.createVideoFormat(useMime, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, bitrate); setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, if (allIntra) 0 else 1)
        }
        enc = MediaCodec.createEncoderByType(useMime)
        enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val inSurface = enc.createInputSurface(); enc.start()
        mux = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        val dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY); val v = IntArray(2); EGL14.eglInitialize(dpy, v, 0, v, 1)
        val cfgs = arrayOfNulls<EGLConfig>(1); val n = IntArray(1)
        EGL14.eglChooseConfig(dpy, intArrayOf(EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8,
            EGL14.EGL_ALPHA_SIZE, 8, EGL14.EGL_RENDERABLE_TYPE, EGLExt.EGL_OPENGL_ES3_BIT_KHR, 0x3142 /*RECORDABLE*/, 1, EGL14.EGL_NONE), 0, cfgs, 0, 1, n, 0)
        val eglCtx = EGL14.eglCreateContext(dpy, cfgs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0)
        val surf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], inSurface, intArrayOf(EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(dpy, surf, surf, eglCtx)
        val comp = Compositor(ctx)
        try {
            comp.init(); comp.resize(project, w, h)
            val total = (project.durationMs * fps / 1000).toInt()
            for (i in 0 until total) {
                comp.draw(project, i * 1000L / fps)
                EGLExt.eglPresentationTimeANDROID(dpy, surf, i * 1_000_000_000L / fps)
                EGL14.eglSwapBuffers(dpy, surf)
                drain(false); onProgress((i + 1f) / total)
            }
            enc.signalEndOfInputStream(); drain(true)
            if (audioTrack >= 0) audio?.write(mux, audioTrack)
        } finally {
            comp.release()
            EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(dpy, surf); EGL14.eglDestroyContext(dpy, eglCtx); EGL14.eglTerminate(dpy)
            runCatching { enc.stop(); enc.release() }; inSurface.release()
            runCatching { if (muxStarted) mux.stop(); mux.release() }
        }
    }

    private fun hasEncoder(mime: String) = android.media.MediaCodecList(android.media.MediaCodecList.REGULAR_CODECS).codecInfos.any { ci -> ci.isEncoder && ci.supportedTypes.any { it.equals(mime, true) } }

    private fun drain(eos: Boolean) {
        while (true) {
            val i = enc.dequeueOutputBuffer(info, if (eos) 10_000 else 0)
            when {
                i == MediaCodec.INFO_TRY_AGAIN_LATER -> if (!eos) return
                i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> { track = mux.addTrack(enc.outputFormat); audioTrack = audio?.format?.let { mux.addTrack(it) } ?: -1; mux.start(); muxStarted = true }
                i >= 0 -> {
                    val b = enc.getOutputBuffer(i)!!
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0 && info.size > 0) {
                        b.position(info.offset); b.limit(info.offset + info.size); mux.writeSampleData(track, b, info)
                    }
                    enc.releaseOutputBuffer(i, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                }
            }
        }
    }
}
