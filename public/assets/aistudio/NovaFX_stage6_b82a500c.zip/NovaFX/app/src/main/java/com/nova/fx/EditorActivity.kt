package com.nova.fx

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.ExifInterface
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.opengl.GLSurfaceView
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.MediaStore
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.Window
import android.view.WindowManager
import android.widget.*
import com.nova.fx.export.Exporter
import com.nova.fx.export.Tracker
import com.nova.fx.gl.Compositor
import com.nova.fx.model.*
import com.nova.fx.ui.CanvasDialog
import com.nova.fx.ui.CurveView
import com.nova.fx.ui.TimelineView
import com.nova.fx.ui.Ui
import java.io.File
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.atan2
import kotlin.math.hypot
import kotlin.math.min

class EditorState {
    val project = Project(); @Volatile var posMs = 0.0; @Volatile var playing = false; @Volatile var exporting = false
    @Volatile var selected: Layer? = null; @Volatile var autoKey = false; @Volatile var trackPick = false
}

private class Prop(val name: String, val min: Float, val max: Float, val get: (Long) -> Float, val set: (Long, Float, Boolean) -> Unit)

class EditorActivity : Activity() {
    private val st = EditorState()
    private lateinit var glView: GLSurfaceView; private lateinit var stage: FrameLayout; private lateinit var timeline: TimelineView
    private lateinit var renderer: EditorRenderer; private lateinit var titleView: TextView
    private lateinit var pid: String; private var pname = "Project"; private var nextId = 1
    private var thermalCut = false; private var lastRender = 0L; private var frames = 0
    private val ui = Handler(Looper.getMainLooper())
    private fun d(v: Float) = Ui.dp(this, v)
    private fun now() = st.posMs.toLong()
    private fun gl(f: () -> Unit) { glView.queueEvent { f() }; glView.requestRender() }          // every scene edit runs on the GL thread

    private val autosaver = object : Runnable { override fun run() { save(); if (Prefs.autosaveMin > 0) ui.postDelayed(this, Prefs.autosaveMin * 60_000L) } }
    private val tick = object : Choreographer.FrameCallback {
        override fun doFrame(n: Long) {
            if (!st.playing) return
            val fps = if (Prefs.previewFpsCap == 0) st.project.fps else minOf(st.project.fps, Prefs.previewFpsCap)
            if (n - lastRender >= 1_000_000_000L / fps - 2_000_000L) { lastRender = n; glView.requestRender(); timeline.invalidate() }
            if (Prefs.thermalGuard && ++frames % 120 == 0) checkThermal()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); requestWindowFeature(Window.FEATURE_NO_TITLE); Prefs.init(this)
        pid = intent.getStringExtra("pid") ?: run { finish(); return }
        pname = ProjectStore.meta(this, pid)?.name ?: "Project"
        val f = ProjectStore.file(this, pid)
        if (f.exists()) runCatching {
            val ld = ProjectIO.load(f); val p = st.project
            p.width = ld.w; p.height = ld.h; p.fps = ld.fps; p.durationMs = ld.dur; p.layers.addAll(ld.layers)
            nextId = (ld.layers.maxOfOrNull { it.id } ?: 0) + 1
        }
        if (Prefs.keepScreenOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        renderer = EditorRenderer(this, st)
        glView = GLSurfaceView(this).apply {
            setEGLContextClientVersion(3); setEGLConfigChooser(8, 8, 8, 8, 0, 0)          // no depth/stencil
            preserveEGLContextOnPause = true; setRenderer(renderer); renderMode = GLSurfaceView.RENDERMODE_WHEN_DIRTY   // idle = 0% GPU
            setOnTouchListener { _, e -> gizmo(e); true }
        }
        stage = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()); addView(glView, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
            addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> layoutPreview() } }
        timeline = TimelineView(this, st) { glView.requestRender() }

        titleView = Ui.text(this, pname, 15f, bold = true).apply { gravity = Gravity.CENTER; setOnClickListener { renameDialog() } }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(Ui.PANEL)
            addView(Ui.chip(this@EditorActivity, "‹ Back") { finishSave() }); addView(titleView, LinearLayout.LayoutParams(0, -2, 1f))
            addView(Ui.chip(this@EditorActivity, "Canvas") { canvasDialog() }); addView(Ui.chip(this@EditorActivity, "Export") { v -> exportDialog(v) }) }

        val bar = LinearLayout(this)
        fun add(label: String, f: (TextView) -> Unit) = bar.addView(Ui.chip(this, label, false, f))
        fun mark(v: TextView, on: Boolean) { v.background = Ui.round(this, if (on) Ui.accent() else Ui.CHIP, 10f) }
        add("▶ Play") { v -> if (!st.exporting) { st.playing = !st.playing; v.text = if (st.playing) "❚❚ Pause" else "▶ Play"
            if (st.playing) { lastRender = 0; Choreographer.getInstance().postFrameCallback(tick) } } }
        add("Video") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("video/*").addCategory(Intent.CATEGORY_OPENABLE), 1) }
        add("Photo") { startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE), 2) }
        add("Text") { textDialog() }
        add("Shape") { AlertDialog.Builder(this).setItems(arrayOf("Rectangle", "Rounded", "Ellipse", "Star")) { _, i -> addLayer(LayerFactory.shape(nextId++, i, st.project)) }.show() }
        add("Adjust") { adjust() }
        add("Effects") { effectsDialog() }
        add("Presets") { presetsDialog() }
        add("Mask") { maskDialog() }
        add("Curve") { curveDialog() }
        add("Slow-mo: Off") { v -> st.selected?.let { l -> l.timeMode = (l.timeMode + 1) % 3; v.text = "Slow-mo: " + arrayOf("Off", "Blend", "Flow")[l.timeMode]; glView.requestRender() } }
        add("Reverse") { v -> st.selected?.let { l -> l.reversed = !l.reversed; mark(v, l.reversed); glView.requestRender() } }
        add("Remap") { st.selected?.let { l -> if (l.source is Source.Video) { gl { l.seedRemap() }
            Toast.makeText(this, "Time remap on. Turn on ◆, move the playhead, set 'Time remap (s)' in Adjust.", Toast.LENGTH_LONG).show() } } }
        add("Bake") { bake() }
        add("3D") { v -> st.selected?.let { l -> l.threeD = !l.threeD; mark(v, l.threeD); glView.requestRender() } }
        add("Track") { v -> val l = st.selected
            if (l == null || st.project.layers.none { it.source is Source.Video }) Toast.makeText(this, "Select the layer to move, with a video in the project.", Toast.LENGTH_LONG).show()
            else { st.trackPick = true; Toast.makeText(this, "Tap the point to follow on the preview.", Toast.LENGTH_LONG).show() } }
        add("◆ Auto-key") { v -> st.autoKey = !st.autoKey; mark(v, st.autoKey) }
        add("Blend") { v -> st.selected?.let { l -> val m = BlendMode.values(); l.blend = m[(l.blend.ordinal + 1) % m.size]; v.text = "Blend: ${l.blend}"; glView.requestRender() } }
        add("Delete") { st.selected?.let { l -> st.selected = null; gl { st.project.layers.remove(l); renderer.comp.drop(l.id) }; timeline.invalidate() } }

        setContentView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.BG)
            addView(top); addView(stage, LinearLayout.LayoutParams(-1, 0, 1f)); addView(timeline, LinearLayout.LayoutParams(-1, d(150f)))
            addView(HorizontalScrollView(this@EditorActivity).apply { isHorizontalScrollBarEnabled = false; addView(bar) }) })
    }

    /** Fit the preview to the canvas aspect, and cap how many pixels the GPU renders (Settings > Preview). */
    private fun layoutPreview() {
        val sw = stage.width; val sh = stage.height; if (sw == 0 || sh == 0) return
        val p = st.project; val fit = min(sw / p.width.toFloat(), sh / p.height.toFloat())
        val fw = maxOf(2, (p.width * fit).toInt()); val fh = maxOf(2, (p.height * fit).toInt())
        val lp = glView.layoutParams as FrameLayout.LayoutParams
        if (lp.width != fw || lp.height != fh) { lp.width = fw; lp.height = fh; glView.layoutParams = lp }
        var cap = Prefs.previewRes; if (thermalCut) cap = if (cap == 0) 360 else min(cap, 360)
        var q = if (cap == 0) 1f else min(1f, cap / min(p.width, p.height).toFloat()); q = min(q, fit)       // never render more pixels than are shown
        glView.holder.setFixedSize(maxOf(2, (p.width * q).toInt()), maxOf(2, (p.height * q).toInt()))
    }

    private fun checkThermal() {
        if (Build.VERSION.SDK_INT < 29) return
        val ts = (getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus
        if (!thermalCut && ts >= PowerManager.THERMAL_STATUS_MODERATE) { thermalCut = true; layoutPreview(); Toast.makeText(this, "Phone is warm: preview quality lowered.", Toast.LENGTH_SHORT).show() }
        else if (thermalCut && ts <= PowerManager.THERMAL_STATUS_NONE) { thermalCut = false; layoutPreview() }
    }

    // ---- on-canvas editing: 1 finger = move, 2 fingers = scale + rotate (keyframed when auto-key is on) ----
    private var lx = 0f; private var ly = 0f; private var pd = 0f; private var pa = 0f
    private fun gizmo(e: MotionEvent) {
        val view = glView.width / st.project.width.toFloat()
        if (st.trackPick) { if (e.actionMasked == MotionEvent.ACTION_DOWN) startTrack(e.x / view, e.y / view); return }
        val l = st.selected; if (l == null || st.playing) return
        fun dist() = hypot(e.getX(0) - e.getX(1), e.getY(0) - e.getY(1))
        fun ang() = Math.toDegrees(atan2((e.getY(1) - e.getY(0)).toDouble(), (e.getX(1) - e.getX(0)).toDouble())).toFloat()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { lx = e.x; ly = e.y }
            MotionEvent.ACTION_POINTER_DOWN -> if (e.pointerCount == 2) { pd = dist(); pa = ang() }
            MotionEvent.ACTION_POINTER_UP -> { val k = if (e.actionIndex == 0) 1 else 0; lx = e.getX(k); ly = e.getY(k) }
            MotionEvent.ACTION_MOVE -> {
                val t = now(); val tr = l.transform; val key = st.autoKey
                if (e.pointerCount == 1) { val dx = (e.x - lx) / view; val dy = (e.y - ly) / view; lx = e.x; ly = e.y
                    gl { tr.x.put(t, tr.x.valueAt(t) + dx, key); tr.y.put(t, tr.y.valueAt(t) + dy, key) }
                } else if (e.pointerCount >= 2) { val dd = dist(); val a = ang(); val f = if (pd > 0) dd / pd else 1f; val da = a - pa; pd = dd; pa = a
                    gl { tr.scaleX.put(t, tr.scaleX.valueAt(t) * f, key); tr.scaleY.put(t, tr.scaleY.valueAt(t) * f, key); tr.rotation.put(t, tr.rotation.valueAt(t) + da, key) } }
            }
        }
    }

    private fun addLayer(l: Layer) { st.selected = l; gl { st.project.layers += l }; timeline.invalidate() }

    private fun textDialog() { val et = EditText(this)
        AlertDialog.Builder(this).setTitle("Text").setView(et).setPositiveButton("Add") { _, _ ->
            val s = et.text.toString(); if (s.isNotBlank()) addLayer(LayerFactory.text(nextId++, s, st.project)) }.show() }

    // ---- property sliders ----
    private fun p(n: String, lo: Float, hi: Float, a: AnimatedFloat) = Prop(n, lo, hi, { a.valueAt(it) }, { t, v, k -> a.put(t, v, k) })

    private fun adjust() {
        val l = st.selected ?: return; val tr = l.transform; val ps = ArrayList<Prop>()
        ps += p("Opacity", 0f, 1f, l.opacity)
        ps += Prop("Scale", 0.05f, 4f, { tr.scaleX.valueAt(it) }, { t, v, k -> tr.scaleX.put(t, v, k); tr.scaleY.put(t, v, k) })
        ps += p("Rotation (Z)", -360f, 360f, tr.rotation); ps += p("Rotate X (3D toggle)", -180f, 180f, tr.rotX); ps += p("Rotate Y (3D toggle)", -180f, 180f, tr.rotY)
        if (l.source is Source.Video) {
            ps += Prop("Speed", 0.1f, 4f, { l.speed }, { _, v, _ -> l.speed = v })
            ps += Prop("Time remap (s)", 0f, maxOf(1f, l.srcDurMs / 1000f), { l.srcMs(it) / 1000f }, { t, v, _ -> if (!l.remap.isAnimated) l.seedRemap(); l.remap.put(t, v, true) })
            ps += Prop("Volume", 0f, 2f, { l.volume }, { _, v, _ -> l.volume = v })
            ps += Prop("Fade in (s)", 0f, 5f, { l.fadeInMs / 1000f }, { _, v, _ -> l.fadeInMs = (v * 1000).toLong() })
            ps += Prop("Fade out (s)", 0f, 5f, { l.fadeOutMs / 1000f }, { _, v, _ -> l.fadeOutMs = (v * 1000).toLong() })
        }
        ps += p("Brightness", -0.5f, 0.5f, l.brightness); ps += p("Contrast", 0f, 2f, l.contrast); ps += p("Saturation", 0f, 2f, l.saturation)
        ps += p("RGB split", 0f, 0.03f, l.rgbSplit); ps += p("Vignette", 0f, 1f, l.vignette); ps += p("Posterize (levels)", 0f, 16f, l.posterize); ps += p("Grain", 0f, 0.5f, l.grain)
        showProps(l.name.ifEmpty { "Layer ${l.id}" }, ps)
    }

    private fun effectsDialog() { val l = st.selected ?: return; showProps("Effects", FX.mapIndexed { i, f -> p(f.name, f.min, f.max, l.e[i]) }) }

    private fun showProps(title: String, props: List<Prop>) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(16f), 0, d(16f), 0) }
        for (pr in props) {
            box.addView(TextView(this).apply { text = pr.name })
            box.addView(SeekBar(this).apply { max = 1000; progress = ((pr.get(now()) - pr.min) / (pr.max - pr.min) * 1000).toInt().coerceIn(0, 1000)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar, v: Int, user: Boolean) { if (!user) return
                        val value = pr.min + v / 1000f * (pr.max - pr.min); val t = now(); val k = st.autoKey; gl { pr.set(t, value, k) } }
                    override fun onStartTrackingTouch(s: SeekBar) {}
                    override fun onStopTrackingTouch(s: SeekBar) {} }) })
        }
        AlertDialog.Builder(this).setTitle(title).setView(ScrollView(this).apply { addView(box) }).setPositiveButton("Done", null).show()
    }

    private fun presetsDialog() {
        val l = st.selected ?: return; val favs = Prefs.favs()
        val entries = ArrayList<Pair<String, () -> Unit>>()
        for (a in Presets.anims.sortedByDescending { it.name in favs })
            entries += Pair((if (a.name in favs) "★ " else "▶ ") + a.name + "  –  " + a.desc, { val t = now(); gl { a.fn(l, t, st.project) } })
        for (lk in Presets.looks.sortedByDescending { it.name in favs })
            entries += Pair((if (lk.name in favs) "★ " else "✦ ") + lk.name + "  –  " + lk.desc, { gl { lk.fn(l) } })
        AlertDialog.Builder(this).setTitle("Presets").setItems(entries.map { it.first }.toTypedArray()) { _, i -> entries[i].second() }.show()
    }

    private fun maskDialog() {
        val l = st.selected ?: return
        AlertDialog.Builder(this).setTitle("Mask").setItems(arrayOf("None", "Rectangle", "Ellipse", "Toggle invert", "Edit mask…")) { _, i ->
            when (i) {
                0, 1, 2 -> gl { l.maskType = i }
                3 -> gl { l.maskInvert = !l.maskInvert }
                else -> showProps("Mask (keyframe with ◆)", listOf(p("X", 0f, 1f, l.maskX), p("Y", 0f, 1f, l.maskY),
                    p("Width", 0.02f, 1.5f, l.maskW), p("Height", 0.02f, 1.5f, l.maskH), p("Feather", 0f, 0.3f, l.maskFeather)))
            }
        }.show()
    }

    private fun curveDialog() {
        val l = st.selected ?: return; val cv = CurveView(this); val row = LinearLayout(this)
        for ((n, v) in listOf("Linear" to floatArrayOf(0f, 0f, 1f, 1f), "Ease" to floatArrayOf(0.42f, 0f, 0.58f, 1f), "In" to floatArrayOf(0.42f, 0f, 1f, 1f),
            "Out" to floatArrayOf(0f, 0f, 0.58f, 1f), "Back" to floatArrayOf(0.34f, 1.56f, 0.64f, 1f)))
            row.addView(Button(this).apply { text = n; textSize = 11f; setOnClickListener { cv.set(v[0], v[1], v[2], v[3]) } }, LinearLayout.LayoutParams(0, -2, 1f))
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(row); addView(cv) }
        AlertDialog.Builder(this).setTitle("Easing").setView(box).setPositiveButton("Apply") { _, _ ->
            val h = cv.handles(); gl { l.animatedProps().forEach { it.applyEase(h[0], h[1], h[2], h[3]) } } }.setNegativeButton("Cancel", null).show()
    }

    // ---- reverse bake: render once into an all-intra proxy ----
    private fun bake() {
        val l = st.selected ?: return; val src = l.source as? Source.Video ?: return
        if (st.exporting) return
        if (!l.reversed || l.remap.isAnimated) { Toast.makeText(this, "Bake: turn Reverse on first (not with time remap).", Toast.LENGTH_LONG).show(); return }
        st.playing = false; st.exporting = true
        val segMs = ((l.outMs - l.inMs) * l.speed).toLong(); val pj = st.project
        val tmp = Project(pj.width, pj.height, pj.fps, segMs)
        tmp.layers += Layer(-1, src, l.width, l.height, 0, segMs, trimMs = l.trimMs).apply { reversed = true
            transform.anchorX.base = l.width / 2; transform.anchorY.base = l.height / 2; transform.x.base = pj.width / 2f; transform.y.base = pj.height / 2f }
        val out = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "proxy_${l.id}_${System.currentTimeMillis()}.mp4")
        Toast.makeText(this, "Baking reversed proxy…", Toast.LENGTH_SHORT).show()
        Thread {
            val ok = runCatching { Exporter(applicationContext, tmp).run(out, 16_000_000, true) { } }
            if (ok.isSuccess) gl { renderer.comp.drop(l.id); l.source = Source.Video(Uri.fromFile(out)); l.trimMs = 0; l.reversed = false; l.audioUri = null; l.srcDurMs = segMs }
            st.exporting = false
            runOnUiThread { Toast.makeText(this, if (ok.isSuccess) "Baked. Reverse is now a normal fast clip." else "Bake failed: ${ok.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show(); timeline.invalidate() }
        }.start()
    }

    // ---- motion tracking: follow a point on the first video, drive the selected layer ----
    private fun startTrack(px: Float, py: Float) {
        st.trackPick = false
        val over = st.selected ?: return; val vid = st.project.layers.firstOrNull { it.source is Source.Video } ?: return
        if (st.exporting) return
        st.exporting = true; st.playing = false
        val t0 = now(); val tr = vid.transform
        val u0 = ((px - tr.x.valueAt(t0)) / tr.scaleX.valueAt(t0) + tr.anchorX.valueAt(t0)) / vid.width
        val vq = ((py - tr.y.valueAt(t0)) / tr.scaleY.valueAt(t0) + tr.anchorY.valueAt(t0)) / vid.height
        val ox = over.transform.x.valueAt(t0) - px; val oy = over.transform.y.valueAt(t0) - py
        val end = minOf(vid.outMs, st.project.durationMs); val uri = (vid.source as Source.Video).uri
        Toast.makeText(this, "Tracking… (assumes the video layer is not rotated)", Toast.LENGTH_SHORT).show()
        Thread {
            val res = runCatching { Tracker(applicationContext, uri).track(t0, end, st.project.fps, u0, 1f - vq) { ms -> vid.srcMs(ms) } }
            st.exporting = false
            res.onSuccess { pts -> gl { for (r in pts) { val t = r[0].toLong(); val vt = vid.transform
                val tx = vt.x.valueAt(t) + (r[1] * vid.width - vt.anchorX.valueAt(t)) * vt.scaleX.valueAt(t)
                val ty = vt.y.valueAt(t) + ((1f - r[2]) * vid.height - vt.anchorY.valueAt(t)) * vt.scaleY.valueAt(t)
                over.transform.x.set(Keyframe(t, tx + ox, Interp.LINEAR)); over.transform.y.set(Keyframe(t, ty + oy, Interp.LINEAR)) } } }
            runOnUiThread { Toast.makeText(this, if (res.isSuccess) "Tracked ${res.getOrNull()?.size ?: 0} frames." else "Tracking failed: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show(); timeline.invalidate() }
        }.start()
    }

    // ---- import ----
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        val uri = data?.data ?: return
        runCatching { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        if (req == 1) importVideo(uri) else if (req == 2) importPhoto(uri)
    }

    private fun importVideo(uri: Uri) {
        val r = MediaMetadataRetriever().apply { setDataSource(this@EditorActivity, uri) }
        fun k(key: Int) = r.extractMetadata(key)?.toLongOrNull() ?: 0L
        var w = k(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH).toFloat(); var h = k(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT).toFloat()
        val rot = k(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION); val dur = k(MediaMetadataRetriever.METADATA_KEY_DURATION); r.release()
        if (rot == 90L || rot == 270L) { val t = w; w = h; h = t }
        val p = st.project; val s = min(p.width / w, p.height / h)
        val layer = Layer(nextId++, Source.Video(uri), w * s, h * s, 0, dur).apply { name = "Video"; srcDurMs = dur; audioUri = uri
            transform.anchorX.base = w * s / 2; transform.anchorY.base = h * s / 2; transform.x.base = p.width / 2f; transform.y.base = p.height / 2f }
        if (p.layers.isEmpty() || dur > p.durationMs) p.durationMs = dur
        addLayer(layer)
    }

    private fun importPhoto(uri: Uri) {
        val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
        var ss = 1; while (maxOf(opts.outWidth, opts.outHeight) / ss > 2048) ss *= 2
        var bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = ss }) } ?: return
        val rot = contentResolver.openInputStream(uri)?.use { s -> when (ExifInterface(s).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f } } ?: 0f
        if (rot != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, android.graphics.Matrix().apply { postRotate(rot) }, true)
        val p = st.project; val s = min(p.width / bmp.width.toFloat(), p.height / bmp.height.toFloat())
        val l = Layer(nextId++, Source.Raster(bmp, true), bmp.width * s, bmp.height * s).apply { name = "Photo"
            transform.anchorX.base = width / 2; transform.anchorY.base = height / 2; transform.x.base = p.width / 2f; transform.y.base = p.height / 2f; outMs = maxOf(p.durationMs, 5000) }
        addLayer(l)
    }

    // ---- project: save, rename, canvas ----
    private fun save() { runCatching { ProjectIO.save(st.project, ProjectStore.file(this, pid)); ProjectStore.saveMeta(this, pid, pname, st.project) } }
    private fun finishSave() { save(); finish() }
    private fun renameDialog() { val et = EditText(this).apply { setText(pname) }
        AlertDialog.Builder(this).setTitle("Rename project").setView(et).setPositiveButton("OK") { _, _ ->
            if (et.text.isNotBlank()) { pname = et.text.toString().trim(); titleView.text = pname; save() } }.show() }

    private fun canvasDialog() {
        val p = st.project
        CanvasDialog.show(this, p.width, p.height, p.fps, "Apply") { w, h, f ->
            p.width = w; p.height = h; p.fps = f; layoutPreview(); gl { renderer.comp.resize(p, renderer.sw, renderer.sh) }
            Toast.makeText(this, "Canvas $w × $h @ $f fps. Layers keep their pixel positions.", Toast.LENGTH_LONG).show() }
    }

    // ---- export (uses Settings > Export) ----
    private fun exportDialog(v: TextView) {
        if (st.exporting || st.project.layers.isEmpty()) { Toast.makeText(this, "Nothing to export yet, or a job is running.", Toast.LENGTH_SHORT).show(); return }
        val p = st.project; val sc = Prefs.exportScale / 100f
        val msg = "${(p.width * sc).toInt() / 2 * 2} × ${(p.height * sc).toInt() / 2 * 2} · ${p.fps} fps\n" +
            "${if (Prefs.exportCodec == 1) "HEVC" else "H.264"} · ${Prefs.exportMbps()} Mbps\n\nChange these under Settings on the Home screen."
        AlertDialog.Builder(this).setTitle("Export").setMessage(msg).setPositiveButton("Export") { _, _ -> export(v) }.setNegativeButton("Cancel", null).show()
    }

    private fun export(v: TextView) {
        st.playing = false; st.exporting = true; save()
        val out = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "${pname.replace(Regex("[^A-Za-z0-9_-]"), "_")}_${System.currentTimeMillis()}.mp4"); var last = -1
        val mime = if (Prefs.exportCodec == 1) MediaFormat.MIMETYPE_VIDEO_HEVC else MediaFormat.MIMETYPE_VIDEO_AVC
        val bitrate = Prefs.exportMbps() * 1_000_000; val scale = Prefs.exportScale / 100f
        Thread {
            val res = runCatching { Exporter(applicationContext, st.project).run(out, bitrate, false, mime, scale) { f ->
                val pc = (f * 100).toInt(); if (pc != last) { last = pc; runOnUiThread { v.text = "Export $pc%" } } } }
            if (res.isSuccess) runCatching { publish(out) }
            st.exporting = false
            runOnUiThread { v.text = "Export"; Toast.makeText(this, if (res.isSuccess) "Saved to Movies/NovaFX" else "Export failed: ${res.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show() }
        }.start()
    }

    private fun publish(f: File) {
        if (Build.VERSION.SDK_INT < 29) return
        val cv = ContentValues().apply { put(MediaStore.Video.Media.DISPLAY_NAME, f.name); put(MediaStore.Video.Media.MIME_TYPE, "video/mp4"); put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/NovaFX") }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv) ?: return
        contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
    }

    override fun onPause() { super.onPause(); st.playing = false; ui.removeCallbacks(autosaver); save(); glView.onPause() }
    override fun onResume() { super.onResume(); glView.onResume(); if (Prefs.autosaveMin > 0) ui.postDelayed(autosaver, Prefs.autosaveMin * 60_000L) }
    @Suppress("OVERRIDE_DEPRECATION") override fun onBackPressed() { finishSave() }
}

class EditorRenderer(ctx: Context, private val st: EditorState) : GLSurfaceView.Renderer {
    val comp = Compositor(ctx.applicationContext); private var last = 0L
    @Volatile var sw = 1; @Volatile var sh = 1
    override fun onSurfaceCreated(g: GL10?, c: EGLConfig?) { comp.release(); comp.init() }
    override fun onSurfaceChanged(g: GL10?, w: Int, h: Int) { sw = w; sh = h; comp.resize(st.project, w, h) }
    override fun onDrawFrame(g: GL10?) {
        comp.lite = Prefs.liteEffects
        val n = System.nanoTime()
        if (st.playing) { if (last != 0L) { st.posMs += (n - last) / 1e6; if (st.posMs >= st.project.durationMs) st.posMs = 0.0 }; last = n } else last = 0
        comp.draw(st.project, st.posMs.toLong())
    }
}
