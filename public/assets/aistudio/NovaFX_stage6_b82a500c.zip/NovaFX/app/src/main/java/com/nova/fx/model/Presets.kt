package com.nova.fx.model

/** Built-in animation presets (write keyframes at the playhead) and looks (set effect values). */
object Presets {
    class Anim(val name: String, val desc: String, val fn: (Layer, Long, Project) -> Unit)
    class Look(val name: String, val desc: String, val fn: (Layer) -> Unit)

    private fun k(a: AnimatedFloat, t: Long, dt: Long, v: Float, ip: Interp = Interp.BEZIER) = a.set(Keyframe(t + dt, v, ip))
    private fun ix(n: String) = FX.indexOfFirst { it.name == n }

    val anims = listOf(
        Anim("Fade in", "Opacity 0 to 1 over 0.5 s") { l, t, _ -> k(l.opacity, t, 0, 0f); k(l.opacity, t, 500, 1f) },
        Anim("Fade out", "Opacity 1 to 0 over 0.5 s") { l, t, _ -> k(l.opacity, t, 0, 1f); k(l.opacity, t, 500, 0f) },
        Anim("Pop in", "Scale up with a small overshoot") { l, t, _ -> val s = l.transform.scaleX.valueAt(t)
            for (a in arrayOf(l.transform.scaleX, l.transform.scaleY)) { k(a, t, 0, 0f); k(a, t, 300, s * 1.15f); k(a, t, 450, s) } },
        Anim("Slide in", "Enter from the left edge") { l, t, p -> val x = l.transform.x.valueAt(t); k(l.transform.x, t, 0, x - p.width); k(l.transform.x, t, 500, x) },
        Anim("Spin in", "Rotate and scale in") { l, t, _ -> val s = l.transform.scaleX.valueAt(t); k(l.transform.rotation, t, 0, -360f); k(l.transform.rotation, t, 600, 0f)
            for (a in arrayOf(l.transform.scaleX, l.transform.scaleY)) { k(a, t, 0, 0f); k(a, t, 600, s) } },
        Anim("Shake", "Quick horizontal shake") { l, t, _ -> val x = l.transform.x.valueAt(t)
            for (j in 0..8) k(l.transform.x, t, j * 60L, x + (if (j % 2 == 0) 18f else -18f), Interp.LINEAR); k(l.transform.x, t, 540, x) },
        Anim("Pulse", "Two soft heartbeats") { l, t, _ -> val s = l.transform.scaleX.valueAt(t)
            for (a in arrayOf(l.transform.scaleX, l.transform.scaleY)) { k(a, t, 0, s); k(a, t, 250, s * 1.12f); k(a, t, 500, s); k(a, t, 750, s * 1.12f); k(a, t, 1000, s) } },
        Anim("Slow zoom", "Ken Burns push-in over 3 s") { l, t, _ -> val s = l.transform.scaleX.valueAt(t)
            for (a in arrayOf(l.transform.scaleX, l.transform.scaleY)) { k(a, t, 0, s); k(a, t, 3000, s * 1.25f, Interp.LINEAR) } },
        Anim("Float", "Gentle up-and-down bob") { l, t, _ -> val y = l.transform.y.valueAt(t); k(l.transform.y, t, 0, y); k(l.transform.y, t, 800, y - 20f); k(l.transform.y, t, 1600, y) },
        Anim("Wiggle", "Rotate left and right") { l, t, _ -> val r = l.transform.rotation.valueAt(t)
            for (j in 0..4) k(l.transform.rotation, t, j * 150L, r + (if (j % 2 == 0) 8f else -8f)); k(l.transform.rotation, t, 750, r) }
    )

    fun clearLook(l: Layer) {
        l.brightness.base = 0f; l.contrast.base = 1f; l.saturation.base = 1f; l.vignette.base = 0f; l.grain.base = 0f; l.posterize.base = 0f; l.rgbSplit.base = 0f
        for (a in l.e) a.base = 0f
    }
    private fun setNamed(l: Layer, n: String, v: Float) {
        when (n) {
            "Brightness" -> l.brightness.base = v; "Contrast" -> l.contrast.base = v; "Saturation" -> l.saturation.base = v
            "Vignette" -> l.vignette.base = v; "Grain" -> l.grain.base = v; "Posterize" -> l.posterize.base = v
            else -> { val i = ix(n); if (i >= 0) l.e[i].base = v }
        }
    }
    private fun look(vararg pairs: Pair<String, Float>): (Layer) -> Unit = { l -> clearLook(l); for ((n, v) in pairs) setNamed(l, n, v) }

    val looks = listOf(
        Look("Cinematic", "Duotone grade, vignette, light grain", look("Duotone" to 0.3f, "Vignette" to 0.5f, "Grain" to 0.1f, "Contrast" to 1.15f, "Saturation" to 0.9f)),
        Look("Vintage", "Sepia, warm, grainy", look("Sepia" to 0.6f, "Grain" to 0.2f, "Vignette" to 0.6f, "Contrast" to 1.1f, "Temperature" to 0.4f)),
        Look("Cyber glitch", "Glitch, aberration, scanlines", look("Glitch" to 0.5f, "Chromatic aberration" to 0.012f, "Scanlines" to 0.4f, "Saturation" to 1.4f, "Contrast" to 1.2f)),
        Look("Dream", "Soft glow and blur", look("Glow" to 1.0f, "Blur" to 1.5f, "Brightness" to 0.05f, "Saturation" to 1.2f, "Temperature" to 0.3f)),
        Look("Noir", "High-contrast black and white", look("Saturation" to 0f, "Contrast" to 1.4f, "Vignette" to 0.7f, "Grain" to 0.15f)),
        Look("Comic", "Posterized with ink edges", look("Posterize" to 5f, "Edge detect" to 0.4f, "Saturation" to 1.5f)),
        Look("VHS", "Aberration, scanlines, flicker", look("Chromatic aberration" to 0.015f, "Scanlines" to 0.6f, "Grain" to 0.2f, "Saturation" to 1.2f, "Flicker" to 0.3f)),
        Look("Clear look", "Remove all colour and effect settings", { l -> clearLook(l) })
    )
}
