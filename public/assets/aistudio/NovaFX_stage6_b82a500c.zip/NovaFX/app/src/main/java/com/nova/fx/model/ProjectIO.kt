package com.nova.fx.model

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File

/** Project <-> JSON. Text/shape layers embed their PNG; video layers store their URI (persistable permission is taken on import). */
object ProjectIO {
    private fun af(a: AnimatedFloat) = JSONObject().put("b", a.base.toDouble()).put("k", JSONArray().also { arr ->
        for (k in a.keyList()) arr.put(JSONArray().put(k.timeMs).put(k.value.toDouble()).put(k.interp.ordinal)
            .put(k.outX.toDouble()).put(k.outY.toDouble()).put(k.inX.toDouble()).put(k.inY.toDouble())) })

    private fun loadAf(a: AnimatedFloat, o: JSONObject) {
        a.base = o.optDouble("b", a.base.toDouble()).toFloat(); val arr = o.optJSONArray("k") ?: return
        for (i in 0 until arr.length()) { val r = arr.getJSONArray(i)
            a.set(Keyframe(r.getLong(0), r.getDouble(1).toFloat(), Interp.values()[r.getInt(2)], r.getDouble(3).toFloat(), r.getDouble(4).toFloat(), r.getDouble(5).toFloat(), r.getDouble(6).toFloat())) }
    }

    fun save(p: Project, f: File) {
        val layers = JSONArray()
        for (l in p.layers) {
            val o = JSONObject().put("id", l.id).put("name", l.name).put("w", l.width.toDouble()).put("h", l.height.toDouble())
                .put("in", l.inMs).put("out", minOf(l.outMs, 3_600_000L)).put("blend", l.blend.ordinal).put("trim", l.trimMs).put("3d", l.threeD)
                .put("speed", l.speed.toDouble()).put("rev", l.reversed).put("srcDur", l.srcDurMs).put("tm", l.timeMode)
                .put("mt", l.maskType).put("mi", l.maskInvert).put("vol", l.volume.toDouble()).put("fi", l.fadeInMs).put("fo", l.fadeOutMs)
            l.audioUri?.let { o.put("audio", it.toString()) }
            when (val s = l.source) {
                is Source.Video -> o.put("src", "v").put("uri", s.uri.toString())
                is Source.Solid -> o.put("src", "s").put("rgb", JSONArray().put(s.r.toDouble()).put(s.g.toDouble()).put(s.b.toDouble()))
                is Source.Raster -> { val bos = ByteArrayOutputStream(); if (s.photo) s.bitmap.compress(Bitmap.CompressFormat.JPEG, 88, bos) else s.bitmap.compress(Bitmap.CompressFormat.PNG, 100, bos)
                    o.put("src", "r").put("photo", s.photo).put("png", Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)) }
                is Source.Texture -> o.put("src", "none")
            }
            val pr = JSONObject(); for ((k, a) in l.props()) pr.put(k, af(a)); o.put("p", pr)
            if (o.getString("src") != "none") layers.put(o)
        }
        f.writeText(JSONObject().put("v", 1).put("dur", p.durationMs).put("w", p.width).put("h", p.height).put("fps", p.fps).put("layers", layers).toString())
    }

    class Loaded(val dur: Long, val w: Int, val h: Int, val fps: Int, val layers: List<Layer>)

    fun load(f: File): Loaded {
        val root = JSONObject(f.readText()); val out = ArrayList<Layer>(); val arr = root.getJSONArray("layers")
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val src: Source = when (o.getString("src")) {
                "v" -> Source.Video(Uri.parse(o.getString("uri")))
                "s" -> { val c = o.getJSONArray("rgb"); Source.Solid(c.getDouble(0).toFloat(), c.getDouble(1).toFloat(), c.getDouble(2).toFloat()) }
                "r" -> { val b = Base64.decode(o.getString("png"), Base64.DEFAULT); Source.Raster(BitmapFactory.decodeByteArray(b, 0, b.size), o.optBoolean("photo")) }
                else -> continue
            }
            val l = Layer(o.getInt("id"), src, o.getDouble("w").toFloat(), o.getDouble("h").toFloat(), o.getLong("in"), o.getLong("out"),
                BlendMode.values()[o.getInt("blend")], o.getLong("trim"))
            l.name = o.optString("name"); l.threeD = o.optBoolean("3d"); l.speed = o.optDouble("speed", 1.0).toFloat(); l.reversed = o.optBoolean("rev")
            l.srcDurMs = o.optLong("srcDur"); l.timeMode = o.optInt("tm"); l.maskType = o.optInt("mt"); l.maskInvert = o.optBoolean("mi")
            l.volume = o.optDouble("vol", 1.0).toFloat(); l.fadeInMs = o.optLong("fi"); l.fadeOutMs = o.optLong("fo")
            if (o.has("audio")) l.audioUri = Uri.parse(o.getString("audio"))
            val pr = o.optJSONObject("p"); if (pr != null) for ((k, a) in l.props()) pr.optJSONObject(k)?.let { loadAf(a, it) }
            out += l
        }
        return Loaded(root.getLong("dur"), root.optInt("w", 1280), root.optInt("h", 720), root.optInt("fps", 30), out)
    }
}
