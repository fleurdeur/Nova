package com.nova.fx.model

import android.graphics.*
import kotlin.math.*

object LayerFactory {
    private val palette = intArrayOf(0xFF7C4DFF.toInt(), 0xFFFF5252.toInt(), 0xFF26A69A.toInt(), 0xFFFFB300.toInt())

    fun text(id: Int, s: String, p: Project): Layer {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 96f; typeface = Typeface.DEFAULT_BOLD }
        val fm = paint.fontMetrics
        val w = min(ceil(paint.measureText(s)).toInt() + 16, 2048); val h = ceil(fm.descent - fm.ascent).toInt() + 16
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        Canvas(bmp).drawText(s, 8f, 8f - fm.ascent, paint)
        return place(Layer(id, Source.Raster(bmp), w.toFloat(), h.toFloat()).also { it.name = s.take(12) }, p)
    }

    /** kind: 0 rectangle, 1 rounded, 2 ellipse, 3 star */
    fun shape(id: Int, kind: Int, p: Project): Layer {
        val w = 400; val h = if (kind == 0) 260 else 400
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = palette[id % palette.size] }
        val c = Canvas(bmp); val r = RectF(2f, 2f, w - 2f, h - 2f)
        when (kind) {
            0 -> c.drawRect(r, paint); 1 -> c.drawRoundRect(r, 60f, 60f, paint); 2 -> c.drawOval(r, paint)
            else -> { val path = Path(); val R = w / 2f * 0.95f
                for (i in 0 until 10) { val rad = if (i % 2 == 0) R else R * 0.4f; val a = Math.toRadians(-90.0 + 36.0 * i)
                    val x = w / 2f + (rad * cos(a)).toFloat(); val y = h / 2f + (rad * sin(a)).toFloat(); if (i == 0) path.moveTo(x, y) else path.lineTo(x, y) }
                path.close(); c.drawPath(path, paint) }
        }
        return place(Layer(id, Source.Raster(bmp), w.toFloat(), h.toFloat()).also { it.name = arrayOf("Rect", "Rounded", "Ellipse", "Star")[kind] }, p)
    }

    private fun place(l: Layer, p: Project): Layer {
        l.transform.anchorX.base = l.width / 2; l.transform.anchorY.base = l.height / 2
        l.transform.x.base = p.width / 2f; l.transform.y.base = p.height / 2f
        l.outMs = maxOf(p.durationMs, 5000); return l
    }
}
