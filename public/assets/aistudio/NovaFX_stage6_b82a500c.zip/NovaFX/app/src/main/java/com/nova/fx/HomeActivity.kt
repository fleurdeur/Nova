package com.nova.fx

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.format.DateFormat
import android.view.Gravity
import android.view.View
import android.view.Window
import android.widget.*
import com.nova.fx.model.Presets
import com.nova.fx.model.ProjectStore
import com.nova.fx.ui.CanvasDialog
import com.nova.fx.ui.Ui

/** Launcher: Home, Projects, Presets and Settings tabs. */
class HomeActivity : Activity() {
    private lateinit var body: FrameLayout; private val tabs = ArrayList<TextView>(); private var cur = 0
    private fun d(v: Float) = Ui.dp(this, v)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b); requestWindowFeature(Window.FEATURE_NO_TITLE); Prefs.init(this)
        val bar = LinearLayout(this).apply { setBackgroundColor(Ui.PANEL) }
        for ((i, n) in listOf("Home", "Projects", "Presets", "Settings").withIndex()) {
            val t = Ui.text(this, n, 13f).apply { gravity = Gravity.CENTER; setPadding(0, d(14f), 0, d(14f)); setOnClickListener { show(i) } }
            tabs += t; bar.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
        }
        body = FrameLayout(this)
        setContentView(LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Ui.BG)
            addView(body, LinearLayout.LayoutParams(-1, 0, 1f)); addView(bar) })
        show(0)
    }
    override fun onResume() { super.onResume(); show(cur) }

    private fun show(i: Int) {
        cur = i; tabs.forEachIndexed { k, t -> t.setTextColor(if (k == i) Ui.accent() else Ui.MUTED) }
        val col = when (i) { 0 -> home(); 1 -> projects(); 2 -> presets(); else -> settings() }
        body.removeAllViews(); body.addView(ScrollView(this).apply { addView(col) })
    }
    private fun page() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(18f), d(22f), d(18f), d(24f)) }
    private fun heading(p: LinearLayout, t: String) = p.addView(Ui.text(this, t, 13f, Ui.accent(), true).apply { setPadding(0, d(18f), 0, d(4f)) })

    private fun open(id: String) = startActivity(Intent(this, EditorActivity::class.java).putExtra("pid", id))
    private fun create(w: Int, h: Int, f: Int) { open(ProjectStore.create(this, ProjectStore.nextName(this), w, h, f)) }
    private fun ratioDims(rw: Int, rh: Int): Pair<Int, Int> {
        val s = minOf(Prefs.defW, Prefs.defH); fun ev(v: Int) = (v / 2) * 2
        return if (rw >= rh) Pair(ev(s * rw / rh), ev(s)) else Pair(ev(s), ev(s * rh / rw))
    }

    // ---------------- Home ----------------
    private fun home(): View {
        val p = page()
        p.addView(Ui.text(this, "NovaFX", 30f, bold = true))
        p.addView(Ui.text(this, "Motion editor tuned for ${Build.MANUFACTURER} ${Build.MODEL}", 13f, Ui.MUTED))
        val nc = Ui.text(this, "＋  New project", 18f, bold = true).apply { gravity = Gravity.CENTER; background = Ui.round(this@HomeActivity, Ui.accent(), 16f); setPadding(0, d(26f), 0, d(26f))
            setOnClickListener { CanvasDialog.show(this@HomeActivity, Prefs.defW, Prefs.defH, Prefs.defFps, "Create") { w, h, f -> create(w, h, f) } } }
        nc.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(20f) }
        p.addView(nc)
        heading(p, "QUICK START")
        p.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(LinearLayout(this@HomeActivity).apply {
            for ((n, r) in listOf("16:9 Video" to (16 to 9), "9:16 Reel" to (9 to 16), "1:1 Square" to (1 to 1), "4:5 Post" to (4 to 5), "21:9 Cinema" to (21 to 9)))
                addView(Ui.chip(this@HomeActivity, n) { val (w, h) = ratioDims(r.first, r.second); create(w, h, Prefs.defFps) })
        }) })
        heading(p, "RECENT")
        val recent = ProjectStore.list(this).take(3)
        if (recent.isEmpty()) p.addView(Ui.text(this, "No projects yet. Create one above.", 13f, Ui.MUTED))
        else recent.forEach { p.addView(projectCard(it)) }
        heading(p, "THIS DEVICE")
        p.addView(Ui.text(this, "${Build.HARDWARE} · Android ${Build.VERSION.RELEASE}\nDefaults: ${Prefs.defW}×${Prefs.defH} @ ${Prefs.defFps} fps, preview ${if (Prefs.previewRes == 0) "full" else Prefs.previewRes.toString() + "p"}", 13f, Ui.MUTED))
        return p
    }

    // ---------------- Projects ----------------
    private fun projectCard(m: ProjectStore.Meta): View = Ui.card(this).apply {
        addView(Ui.text(this@HomeActivity, m.name, 16f, bold = true))
        addView(Ui.text(this@HomeActivity, "${m.w}×${m.h} · ${m.fps} fps · ${m.layers} layers · ${DateFormat.format("MMM d, HH:mm", m.modified)}", 12f, Ui.MUTED))
        setOnClickListener { open(m.id) }; setOnLongClickListener { projectMenu(m); true }
    }

    private fun projects(): View {
        val p = page(); p.addView(Ui.text(this, "Projects", 26f, bold = true)); p.addView(Ui.text(this, "Tap to open, long-press for more.", 13f, Ui.MUTED))
        val all = ProjectStore.list(this)
        if (all.isEmpty()) p.addView(Ui.text(this, "\nNothing here yet.", 14f, Ui.MUTED)) else all.forEach { p.addView(projectCard(it)) }
        return p
    }

    private fun projectMenu(m: ProjectStore.Meta) {
        AlertDialog.Builder(this).setTitle(m.name).setItems(arrayOf("Rename", "Duplicate", "Delete")) { _, i ->
            when (i) {
                0 -> { val et = EditText(this).apply { setText(m.name) }
                    AlertDialog.Builder(this).setTitle("Rename").setView(et).setPositiveButton("OK") { _, _ -> if (et.text.isNotBlank()) { ProjectStore.rename(this, m.id, et.text.toString().trim()); show(cur) } }.show() }
                1 -> { ProjectStore.duplicate(this, m.id); show(cur) }
                else -> AlertDialog.Builder(this).setTitle("Delete \"${m.name}\"?").setMessage("This cannot be undone.")
                    .setPositiveButton("Delete") { _, _ -> ProjectStore.delete(this, m.id); show(cur) }.setNegativeButton("Cancel", null).show()
            }
        }.show()
    }

    // ---------------- Presets ----------------
    private fun presets(): View {
        val p = page(); p.addView(Ui.text(this, "Presets", 26f, bold = true))
        p.addView(Ui.text(this, "Apply them in the editor: select a layer, then Presets. Star your favourites to list them first.", 13f, Ui.MUTED))
        val favs = Prefs.favs()
        fun entry(name: String, desc: String): View = Ui.card(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            val col = LinearLayout(this@HomeActivity).apply { orientation = LinearLayout.VERTICAL
                addView(Ui.text(this@HomeActivity, name, 15f, bold = true)); addView(Ui.text(this@HomeActivity, desc, 12f, Ui.MUTED)) }
            addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            addView(Ui.text(this@HomeActivity, if (name in favs) "★" else "☆", 22f, Ui.accent()).apply { setPadding(d(10f), 0, d(4f), 0); setOnClickListener { Prefs.toggleFav(name); show(2) } })
        }
        heading(p, "ANIMATIONS"); Presets.anims.forEach { p.addView(entry(it.name, it.desc)) }
        heading(p, "LOOKS"); Presets.looks.forEach { p.addView(entry(it.name, it.desc)) }
        return p
    }

    // ---------------- Settings ----------------
    private fun row(title: String, value: String, onClick: () -> Unit): View = Ui.card(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        addView(Ui.text(this@HomeActivity, title, 15f), LinearLayout.LayoutParams(0, -2, 1f)); addView(Ui.text(this@HomeActivity, value, 13f, Ui.MUTED))
        setOnClickListener { onClick() }
    }
    private fun choice(title: String, labels: List<String>, values: List<Int>, cur: Int, set: (Int) -> Unit): View {
        val idx = values.indexOf(cur).coerceAtLeast(0)
        return row(title, labels[idx]) { AlertDialog.Builder(this).setTitle(title).setSingleChoiceItems(labels.toTypedArray(), idx) { dlg, i -> set(values[i]); dlg.dismiss(); show(3) }.show() }
    }
    private fun toggle(title: String, sub: String, on: Boolean, set: (Boolean) -> Unit): View = Ui.card(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        val col = LinearLayout(this@HomeActivity).apply { orientation = LinearLayout.VERTICAL
            addView(Ui.text(this@HomeActivity, title, 15f)); if (sub.isNotEmpty()) addView(Ui.text(this@HomeActivity, sub, 12f, Ui.MUTED)) }
        addView(col, LinearLayout.LayoutParams(0, -2, 1f))
        addView(Switch(this@HomeActivity).apply { isChecked = on; setOnCheckedChangeListener { _, c -> set(c) } })
    }

    private fun settings(): View {
        val p = page(); p.addView(Ui.text(this, "Settings", 26f, bold = true))
        heading(p, "PERFORMANCE PROFILE")
        p.addView(Ui.text(this, "One tap sets preview, effects and export together. Balanced is tuned for Helio G88 / Mali-G52 phones such as the Infinix Hot 30.", 12f, Ui.MUTED))
        p.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(LinearLayout(this@HomeActivity).apply {
            for ((i, n) in listOf("Battery saver", "Balanced (G88)", "Quality").withIndex())
                addView(Ui.chip(this@HomeActivity, n) { Prefs.applyProfile(i); Toast.makeText(this@HomeActivity, "$n profile applied", Toast.LENGTH_SHORT).show(); show(3) })
        }) })

        heading(p, "NEW PROJECT DEFAULTS")
        p.addView(row("Canvas size & frame rate", "${Prefs.defW}×${Prefs.defH} @ ${Prefs.defFps}") {
            CanvasDialog.show(this, Prefs.defW, Prefs.defH, Prefs.defFps, "Save") { w, h, f -> Prefs.defW = w; Prefs.defH = h; Prefs.defFps = f; show(3) } })

        heading(p, "PREVIEW")
        p.addView(choice("Preview resolution", listOf("Full", "720p", "540p (recommended)", "360p"), listOf(0, 720, 540, 360), Prefs.previewRes) { Prefs.previewRes = it })
        p.addView(choice("Preview frame rate", listOf("Match project", "Up to 30 fps", "Up to 60 fps"), listOf(0, 30, 60), Prefs.previewFpsCap) { Prefs.previewFpsCap = it })
        p.addView(toggle("Lite effects in preview", "Optical flow shows as frame blend; glow and zoom blur are skipped. Export is always full quality.", Prefs.liteEffects) { Prefs.liteEffects = it })
        p.addView(toggle("Thermal guard", "Lower preview quality automatically when the phone gets warm (Android 10+).", Prefs.thermalGuard) { Prefs.thermalGuard = it })
        p.addView(choice("Optical-flow detail", listOf("Fast (128)", "Standard (192)", "Fine (256)"), listOf(128, 192, 256), Prefs.flowRes) { Prefs.flowRes = it })

        heading(p, "EXPORT")
        p.addView(choice("Quality", listOf("Low (4 Mbps)", "Medium (8 Mbps)", "High (16 Mbps)", "Custom"), listOf(0, 1, 2, 3), Prefs.exportQuality) { Prefs.exportQuality = it })
        if (Prefs.exportQuality == 3) p.addView(row("Custom bitrate (Mbps)", "${Prefs.exportCustomMbps}") {
            val et = EditText(this).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER; setText(Prefs.exportCustomMbps.toString()) }
            AlertDialog.Builder(this).setTitle("Bitrate (1 to 80 Mbps)").setView(et).setPositiveButton("OK") { _, _ ->
                Prefs.exportCustomMbps = (et.text.toString().toIntOrNull() ?: 10).coerceIn(1, 80); show(3) }.show() })
        p.addView(choice("Codec", listOf("H.264 (most compatible)", "HEVC / H.265 (smaller files)"), listOf(0, 1), Prefs.exportCodec) { Prefs.exportCodec = it })
        p.addView(choice("Export resolution", listOf("100% of canvas", "75%", "50%"), listOf(100, 75, 50), Prefs.exportScale) { Prefs.exportScale = it })

        heading(p, "GENERAL")
        p.addView(choice("Autosave", listOf("Off (saves on exit)", "Every minute", "Every 2 minutes", "Every 5 minutes"), listOf(0, 1, 2, 5), Prefs.autosaveMin) { Prefs.autosaveMin = it })
        p.addView(toggle("Keep screen on while editing", "", Prefs.keepScreenOn) { Prefs.keepScreenOn = it })
        p.addView(toggle("Haptic feedback", "", Prefs.haptics) { Prefs.haptics = it })
        p.addView(choice("Accent colour", Ui.paletteNames, listOf(0, 1, 2, 3, 4), Prefs.accent) { Prefs.accent = it })

        heading(p, "ABOUT")
        p.addView(Ui.text(this, "NovaFX 0.1 · ${Build.MANUFACTURER} ${Build.MODEL} · ${Build.HARDWARE}", 12f, Ui.MUTED))
        p.addView(row("Reset all settings", "") { AlertDialog.Builder(this).setTitle("Reset settings?").setMessage("Projects are kept.")
            .setPositiveButton("Reset") { _, _ -> Prefs.reset(); show(3) }.setNegativeButton("Cancel", null).show() })
        return p
    }
}
