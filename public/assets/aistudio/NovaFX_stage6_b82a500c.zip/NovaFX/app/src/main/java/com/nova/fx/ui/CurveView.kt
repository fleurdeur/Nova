package com.nova.fx.ui

import android.content.Context
import android.graphics.*
import android.view.*

/** Drag the two Bezier handles (CSS cubic-bezier). y may leave 0..1 for overshoot/bounce. */
class CurveView(c: Context) : View(c) {
    private val dp = resources.displayMetrics.density; private val pad = 24 * dp
    private val h = floatArrayOf(0.42f, 0f, 0.58f, 1f); private var drag = -1
    private val curve = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF7C4DFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 3 * dp }
    private val guide = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF55555F.toInt(); style = Paint.Style.STROKE; strokeWidth = 1 * dp }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    fun handles() = h.copyOf()
    fun set(a: Float, b: Float, c2: Float, d: Float) { h[0] = a; h[1] = b; h[2] = c2; h[3] = d; invalidate() }
    private fun px(x: Float) = pad + x * (width - 2 * pad)
    private fun py(y: Float) = height - pad - (y + 0.5f) / 2f * (height - 2 * pad)
    override fun onMeasure(w: Int, hh: Int) { val s = minOf(MeasureSpec.getSize(w), (320 * dp).toInt()); setMeasuredDimension(s, s) }
    override fun onDraw(cv: Canvas) {
        cv.drawColor(0xFF1B1B20.toInt()); cv.drawRect(px(0f), py(1f), px(1f), py(0f), guide); cv.drawLine(px(0f), py(0f), px(1f), py(1f), guide)
        cv.drawLine(px(0f), py(0f), px(h[0]), py(h[1]), guide); cv.drawLine(px(1f), py(1f), px(h[2]), py(h[3]), guide)
        val p = Path().apply { moveTo(px(0f), py(0f)); cubicTo(px(h[0]), py(h[1]), px(h[2]), py(h[3]), px(1f), py(1f)) }; cv.drawPath(p, curve)
        cv.drawCircle(px(h[0]), py(h[1]), 9 * dp, dot); cv.drawCircle(px(h[2]), py(h[3]), 9 * dp, dot)
    }
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { val d0 = Math.hypot((e.x - px(h[0])).toDouble(), (e.y - py(h[1])).toDouble()); val d1 = Math.hypot((e.x - px(h[2])).toDouble(), (e.y - py(h[3])).toDouble())
                drag = if (minOf(d0, d1) < 48 * dp) (if (d0 <= d1) 0 else 1) else -1; parent.requestDisallowInterceptTouchEvent(true) }
            MotionEvent.ACTION_MOVE -> if (drag >= 0) { h[drag * 2] = ((e.x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)
                h[drag * 2 + 1] = (((height - pad - e.y) / (height - 2 * pad)) * 2f - 0.5f).coerceIn(-0.5f, 1.5f); invalidate() }
        }
        return true
    }
}
