package com.nova.fx.ui

import android.app.AlertDialog
import android.content.Context
import android.text.InputType
import android.view.View
import android.widget.*

/** Canvas size + frame rate: pick an aspect ratio, a resolution, or type any width and height; any fps from 1 to 120. */
object CanvasDialog {
    private val ratios = listOf("16:9" to (16 to 9), "9:16" to (9 to 16), "1:1" to (1 to 1), "4:5" to (4 to 5), "21:9" to (21 to 9), "4:3" to (4 to 3), "3:4" to (3 to 4))
    private val resos = listOf("480p" to 480, "720p" to 720, "1080p" to 1080, "1440p" to 1440, "2160p" to 2160)
    private val fpsList = listOf(24, 25, 30, 50, 60)
    private fun even(v: Int) = (v.coerceIn(64, 4096) / 2) * 2

    fun show(ctx: Context, w0: Int, h0: Int, fps0: Int, okLabel: String, onOk: (Int, Int, Int) -> Unit) {
        fun num(et: EditText, d: Int) = et.text.toString().toIntOrNull() ?: d
        fun numEt(v: Int) = EditText(ctx).apply { inputType = InputType.TYPE_CLASS_NUMBER; setText(v.toString()); setTextColor(-1); minEms = 4 }
        val wEt = numEt(w0); val hEt = numEt(h0); val fEt = numEt(fps0)
        val summary = Ui.text(ctx, "", 13f, Ui.MUTED); val warn = Ui.text(ctx, "", 12f, 0xFFFFB300.toInt())
        var rw = w0; var rh = h0
        fun refresh() {
            val w = num(wEt, w0); val h = num(hEt, h0); val f = num(fEt, fps0)
            summary.text = "$w × $h  @  $f fps"
            warn.text = if (w.toLong() * h * f > 1920L * 1080 * 30) "Above this phone's comfortable limit (about 1080p30). Preview will run reduced and export may be slow or fail." else ""
        }
        fun setDims(a: Int, b: Int, short: Int) {
            val w = if (a >= b) even(short * a / b) else even(short); val h = if (a >= b) even(short) else even(short * b / a)
            wEt.setText(w.toString()); hEt.setText(h.toString()); refresh()
        }
        val watcher = object : android.text.TextWatcher {
            override fun afterTextChanged(s: android.text.Editable?) { refresh() }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        }
        wEt.addTextChangedListener(watcher); hEt.addTextChangedListener(watcher); fEt.addTextChangedListener(watcher)

        fun rowOf(items: List<View>) = HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false
            addView(LinearLayout(ctx).apply { items.forEach { addView(it) } }) }
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(Ui.dp(ctx, 18f), Ui.dp(ctx, 6f), Ui.dp(ctx, 18f), 0) }
        box.addView(Ui.text(ctx, "Aspect ratio", 13f, Ui.MUTED))
        box.addView(rowOf(ratios.map { (n, r) -> Ui.chip(ctx, n) { rw = r.first; rh = r.second; setDims(rw, rh, minOf(num(wEt, w0), num(hEt, h0))) } }))
        box.addView(Ui.text(ctx, "Resolution (short side)", 13f, Ui.MUTED))
        box.addView(rowOf(resos.map { (n, v) -> Ui.chip(ctx, n) { setDims(rw, rh, v) } }))
        box.addView(Ui.text(ctx, "Custom width × height", 13f, Ui.MUTED))
        box.addView(LinearLayout(ctx).apply { gravity = android.view.Gravity.CENTER_VERTICAL; addView(wEt); addView(Ui.text(ctx, "  ×  ", 16f)); addView(hEt) })
        box.addView(Ui.text(ctx, "Frame rate", 13f, Ui.MUTED))
        box.addView(rowOf(fpsList.map { f -> Ui.chip(ctx, "$f") { fEt.setText(f.toString()) } }))
        box.addView(LinearLayout(ctx).apply { gravity = android.view.Gravity.CENTER_VERTICAL; addView(Ui.text(ctx, "Custom fps  ", 14f)); addView(fEt) })
        box.addView(summary); box.addView(warn); refresh()

        AlertDialog.Builder(ctx).setTitle("Canvas & frame rate").setView(ScrollView(ctx).apply { addView(box) })
            .setPositiveButton(okLabel) { _, _ -> onOk(even(num(wEt, w0)), even(num(hEt, h0)), num(fEt, fps0).coerceIn(1, 120)) }
            .setNegativeButton("Cancel", null).show()
    }
}
