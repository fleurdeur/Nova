package com.nova.fx

import android.content.Context
import android.content.SharedPreferences

/** All user preferences. Everything here is read live, so a change takes effect the next time the screen/editor asks. */
object Prefs {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("novafx", Context.MODE_PRIVATE) }
    private fun i(k: String, d: Int) = sp.getInt(k, d)
    private fun put(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    private fun b(k: String, d: Boolean) = sp.getBoolean(k, d)
    private fun put(k: String, v: Boolean) = sp.edit().putBoolean(k, v).apply()

    // new-project defaults
    var defW: Int
        get() = i("defW", 1280)
        set(v) = put("defW", v)
    var defH: Int
        get() = i("defH", 720)
        set(v) = put("defH", v)
    var defFps: Int  // preview / performance
        get() = i("defFps", 30)
        set(v) = put("defFps", v)
    var previewRes: Int  // short-side cap in px, 0 = full
        get() = i("previewRes", 540)
        set(v) = put("previewRes", v)
    var previewFpsCap: Int  // 0 = match project fps
        get() = i("previewFpsCap", 0)
        set(v) = put("previewFpsCap", v)
    var liteEffects: Boolean  // preview: optical flow -> blend, skip glow/zoom blur
        get() = b("lite", true)
        set(v) = put("lite", v)
    var thermalGuard: Boolean
        get() = b("thermal", true)
        set(v) = put("thermal", v)
    var flowRes: Int  // optical-flow field size (long side)
        get() = i("flowRes", 192)
        set(v) = put("flowRes", v)
    // export
    var exportQuality: Int
        get() = i("expQ", 1)
        set(v) = put("expQ", v)
    var exportCustomMbps: Int
        get() = i("expMbps", 10)
        set(v) = put("expMbps", v)
    var exportCodec: Int  // 0 H.264, 1 HEVC
        get() = i("expCodec", 0)
        set(v) = put("expCodec", v)
    var exportScale: Int
        get() = i("expScale", 100)
        set(v) = put("expScale", v)
    fun exportMbps() = when (exportQuality) { 0 -> 4; 1 -> 8; 2 -> 16; else -> exportCustomMbps.coerceIn(1, 80) }
    // general
    var autosaveMin: Int
        get() = i("autosave", 2)
        set(v) = put("autosave", v)
    var keepScreenOn: Boolean
        get() = b("keepOn", true)
        set(v) = put("keepOn", v)
    var accent: Int
        get() = i("accent", 0)
        set(v) = put("accent", v)
    var haptics: Boolean  // favourite presets
        get() = b("haptics", true)
        set(v) = put("haptics", v)
    fun favs(): Set<String> = sp.getStringSet("favs", emptySet()) ?: emptySet()
    fun toggleFav(n: String) { val s = favs().toMutableSet(); if (!s.add(n)) s.remove(n); sp.edit().putStringSet("favs", s).apply() }

    /** 0 battery saver, 1 balanced (recommended for Helio G88 / Mali-G52), 2 quality */
    fun applyProfile(p: Int) {
        when (p) {
            0 -> { previewRes = 360; previewFpsCap = 30; liteEffects = true; thermalGuard = true; flowRes = 128; exportQuality = 0 }
            1 -> { previewRes = 540; previewFpsCap = 0; liteEffects = true; thermalGuard = true; flowRes = 192; exportQuality = 1 }
            else -> { previewRes = 720; previewFpsCap = 60; liteEffects = false; thermalGuard = true; flowRes = 256; exportQuality = 2 }
        }
    }
    fun reset() { sp.edit().clear().apply() }
}
