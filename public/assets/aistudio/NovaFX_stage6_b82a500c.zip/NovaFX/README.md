# NovaFX

Open this folder in Android Studio (Hedgehog or newer; let it create the Gradle wrapper), pick the `app` configuration, run on the phone.
Requires an arm64 device with OpenGL ES 3.0 and Android 8.0+ (minSdk 26).

Screens: Home, Projects, Presets, Settings (HomeActivity) and the editor (EditorActivity).
Projects are stored in the app's private storage and autosave; exports go to Movies/NovaFX.

Source map
- gl/        Compositor (all rendering), VideoSource (decode, frame blend, optical flow), FrameTools (offscreen passes)
- export/    Exporter (H.264/HEVC), AudioCopy (lossless passthrough), AudioMix (volume/fades/overlap), Tracker
- model/     Project, Layer, keyframes, effects table, presets, save/load, project store
- ui/        Timeline, curve editor, canvas/frame-rate dialog, small UI kit
